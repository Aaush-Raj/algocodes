from alice_blue import *
import sys
import math
import time
import datetime
from datetime import date,timedelta


def round_nearest(x, num=50): return int(round((x/100))*100)
def nearest_strike_bnf(x): return round_nearest(x, 100)



access_token = AliceBlue.login_and_get_access_token(username="285915",
                                                    password="Test@123",
                                                    twoFA='1996',
                                                    api_secret='kRg5a2cpn0ltTFdMIUhi2MaTuGQkR5oW6VExfIOj29k6oxEgOdujHBzGlNQMru0i',
                                                    app_id='GNqF2bHlyB')

alice = AliceBlue(username='285915', password="Test@123",
                  access_token=access_token)

symbol = 'Nifty Bank'
bnf_script = alice.get_instrument_by_symbol('NSE', symbol)

time.sleep(2)
socket_opened = False


def event_handler_quote_update(message):
    global ltp_bnf
    ltp_bnf = message['ltp']

def open_callback():
    global socket_opened
    socket_opened = True


alice.start_websocket(subscribe_callback=event_handler_quote_update,
                      socket_open_callback=open_callback,
                      run_in_background=True)

while(socket_opened == False):
    pass

alice.subscribe(bnf_script, LiveFeedType.COMPACT)
time.sleep(5)

def open_socket_now():
    global socket_opened
    socket_opened = False
    alice.start_websocket(subscribe_callback=event_handler_quote_update,
                          socket_open_callback=open_callback, run_in_background=True)
    time.sleep(2)

    while (socket_opened == False):
        pass


if socket_opened == False:
    open_socket_now()

random_strike_price = 35200
def latest_expiry():
    call = None
    exp_d = 0
    date_today = date.today()
    while call ==None:
        call = alice.get_instrument_for_fno(symbol="BANKNIFTY", expiry_date=date_today, is_fut=False, strike=random_strike_price, is_CE=True)
        if call ==None:
            date_today = date_today + timedelta(days=1)
        elif call != None:
            exp_d = date_today
            return exp_d
            break

expiry_date =latest_expiry()


def order_status(oid):    
    order_details =alice.get_order_history(oid)
    order_status = order_details['data'][0]['order_status']
    print('ORDER STATUS FUNCTION IS IN USE')
    return order_status
    

def ap_generator(oid):
    order_details =alice.get_order_history(int(oid))
    avg_price = order_details['data'][0]['average_price']
    return avg_price


def sell_atm_options():
    global ce_sell_avg_price, pe_sell_avg_price, sl_bn_ce_sell, tgp_bn_ce_sell, sl_bn_pe_sell, tgp_bn_pe_sell, bn_ce_sell_order_id, bn_pe_sell_order_id
    sell_call_order = alice.place_order(TransactionType.Sell,
                                        instrument = bn_ce_trade,
                                        quantity = 25,
                                        order_type = OrderType.Market,
                                        product_type = ProductType.Intraday)

    sell_put_order = alice.place_order(TransactionType.Sell,
                                        instrument = bn_pe_trade,
                                        quantity = 25,
                                        order_type = OrderType.Market,
                                        product_type = ProductType.Intraday)
    
    bn_ce_sell_order_id = sell_call_order['data']['oms_order_id']
    bn_pe_sell_order_id = sell_put_order['data']['oms_order_id']
    ce_sell_avg_price =ap_generator(bn_ce_sell_order_id) 
    pe_sell_avg_price =ap_generator(bn_pe_sell_order_id)
    
    print("%%%%--- ORDER PLACEMENT----%%%%",sell_call_order,sell_put_order)
    
    #stoploss amount generation code
    sl_bn_ce_sell = float(int(ce_sell_avg_price + (ce_sell_avg_price*0.25)))
    tgp_bn_ce_sell = float(int(sl_bn_ce_sell + 10 ))

    sl_bn_pe_sell = float(int(pe_sell_avg_price + (pe_sell_avg_price*0.25)))
    tgp_bn_pe_sell = float(int(sl_bn_pe_sell + 10 ))

    print("CALL ORDER SL DETAILS--",sl_bn_ce_sell,tgp_bn_ce_sell)
    print("PUT ORDER SL DETAILS--",sl_bn_pe_sell,tgp_bn_pe_sell)

def stoploss_order():
    global sl_ce_oid,sl_pe_oid
    sl_ce_order = alice.place_order(transaction_type = TransactionType.Buy,
                     instrument = bn_ce_trade,
                                   quantity = 25,
                                   order_type = OrderType.StopLossLimit,
                                   product_type = ProductType.Intraday,
                                   
                                   trigger_price =tgp_bn_ce_sell,
                                   stop_loss = sl_bn_ce_sell,
                                   is_amo = False)

    sl_pe_order = alice.place_order(transaction_type = TransactionType.Buy,
                     instrument =  bn_pe_trade,
                                   quantity = 25,
                                   order_type = OrderType.StopLossLimit,
                                   product_type = ProductType.Intraday,
                                   trigger_price =tgp_bn_pe_sell,
                                   stop_loss = sl_bn_pe_sell,
                                   is_amo = False)

    print("%%%%SL ORDER PLACEMENT%%%%",sl_ce_order,sl_pe_order)

    sl_ce_oid = sl_ce_order['data']['oms_order_id']
    sl_pe_oid = sl_pe_order['data']['oms_order_id']
    
def exit_orders():
    #WHEN TIME IS 3:10 ---ORDER CLOSING LOGIC
    alice.cancel_order(sl_ce_oid)
    alice.cancel_order(sl_pe_oid)

    #PlACE OPPOSITE ORDERS FOR CLOSING CURRENT POSITIONS-->
    
    #bn sell call order opposite 
    exit_ce_sell = alice.place_order(TransactionType.Buy,
                                        instrument = bn_ce_trade,
                                        quantity = 25,
                                        order_type = OrderType.Market,
                                        product_type = ProductType.Intraday)
    #bn sell Put order opposite 
    exit_pe_sell = alice.place_order(TransactionType.Buy,
                                        instrument = bn_pe_trade,
                                        quantity = 25,
                                        order_type = OrderType.Market,
                                        product_type = ProductType.Intraday)
    


order_placed = False
while datetime.datetime.now().time() < datetime.time(9,20):
    print("wait for the time to be 9:20 ; Right now the time is only -->)",datetime.datetime.now().time())
    time.sleep(5)
try:
    bnf_nearest_strike = nearest_strike_bnf(ltp_bnf)
    alice.unsubscribe(bnf_script, LiveFeedType.COMPACT)

    bn_ce_trade = alice.get_instrument_for_fno(symbol='BANKNIFTY', expiry_date=expiry_date, is_fut=False, strike=bnf_nearest_strike, is_CE=True)

    bn_pe_trade = alice.get_instrument_for_fno(symbol='BANKNIFTY', expiry_date=expiry_date, is_fut=False, strike=bnf_nearest_strike, is_CE=False)

    sell_atm_options()
    if order_status(bn_ce_sell_order_id) == "rejected" and order_status(bn_pe_sell_order_id) == "rejected":
        print("Orders are rejected so Stoploss orders won't be placed, Please try again.")
        sys.exit(0) 
    else:
        stoploss_order()
    print("All Orders Placed Successfully! Now Just wait till 3:10PM. ")
    
   
except Exception as e:
    print(f"ERROR---->>>>{e}")
    
#EXIT ORDER LOGIC
while datetime.datetime.now().time() < datetime.time(15,10):
    print("wait for the time to be 15:10 ; Right now the time is only -->)",datetime.datetime.now().time())
    time.sleep(5)
try:
    exit_orders()
    print("DONE FOR THE DAY, HOPE YOU MADE GOOD PROFITS")
    
except Exception as e:
    print(f"ERROR---->>>>{e}")
